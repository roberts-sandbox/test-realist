// server.js

var session = require('connect').session
  , cookieParser = require('connect').cookieParser
  , flatiron = require('flatiron')
  , app = flatiron.app
  , fs = require('fs')
  ;

app.use(flatiron.plugins.http);

app.http.before.push(cookieParser('todo list secret'));
app.http.before.push(session());

app.router.get('/', function() {
  var self = this;
  fs.readFile('index.html', function(err, data) {
    if(err) {
      self.res.writeHead(404);
      self.res.end();
      return;
    }
    self.res.writeHead(200, {'Content-Type': 'text/html'});
    self.res.end(data);
  })
});

app.start(8090);
