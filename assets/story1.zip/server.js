// server.js

var session = require('connect').session
  , cookieParser = require('connect').cookieParser
  , flatiron = require('flatiron')
  , app = flatiron.app
  ;

app.use(flatiron.plugins.http);

app.http.before.push(cookieParser('todo list secret')); // secret here
app.http.before.push(session()); // no secret here

app.router.get('/', function() {
  this.res.end();
});

app.start(8090);
