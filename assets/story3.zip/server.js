// server.js

var session = require('connect').session
  , cookieParser = require('connect').cookieParser
  , flatiron = require('flatiron')
  , app = flatiron.app
  , fs = require('fs')
  , resourceful = require('resourceful')
  , qs = require('querystring')
  ;

var Task = resourceful.define('task', function() {
  this.timestamps();
  this.string('desc').required(true)
                     .minLength(1);
});

app.use(flatiron.plugins.http);

app.http.before.push(cookieParser('todo list secret'));
app.http.before.push(session({cookie: {maxAge: 60000}}));

app.router.get('/', function() {
  var self = this;
  fs.readFile('index.html', function(err, data) {
    if(err) {
      self.res.writeHead(404);
      self.res.end();
      return;
    }
    self.res.writeHead(200, {'Content-Type': 'text/html'});
    self.res.end(data);
  })
});

app.router.post('/', function() {
  var self = this;
  var task = new (Task)({desc: self.req.body.desc});
  if(!self.req.session.tasks) {
    self.req.session.tasks = [];
  }
  self.req.session.tasks.push(task);
  self.res.writeHead(303, {'Location': '/'});
  self.res.end();
});

app.start(8090);
